const express = require("express");
const crypto = require("node:crypto");
const sqlite3 = require("sqlite3").verbose();
const { verifyPassword } = require("./admin-auth.cjs");

const SESSION_LIFETIME_MS = 24 * 60 * 60 * 1000;

function createAdminRouter(dbPath = "database.db", onMachinesChanged = () => {}, sendMqttCommand) {
  const router = express.Router();
  const allowedOrigins = new Set([
    "https://laundry-app-test1.vercel.app"
  ]);

  router.use((req, res, next) => {
    const origin = req.get("Origin");

    if (origin && allowedOrigins.has(origin)) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Vary", "Origin");
      res.setHeader(
        "Access-Control-Allow-Headers",
        "Content-Type, Authorization"
      );
      res.setHeader(
        "Access-Control-Allow-Methods",
        "GET, POST, PATCH, OPTIONS"
      );
    }

    if (req.method === "OPTIONS") {
      return origin && allowedOrigins.has(origin)
        ? res.sendStatus(204)
        : res.sendStatus(403);
    }


    if (origin && !allowedOrigins.has(origin)) {
      return res.status(403).json({ error: "Origin not allowed" });
    }

    next();
  });

  const db = new sqlite3.Database(dbPath);

  function createToken() {
    return crypto.randomBytes(32).toString("hex");
  }

  function hashToken(token) {
    return crypto.createHash("sha256").update(token).digest("hex");
  }



  const loginAttempts = new Map();
  const LOGIN_WINDOW_MS = 15 * 60 * 1000;
  const MAX_LOGIN_FAILURES = 5;

  function loginRateLimit(req, res, next) {
    const key = req.ip;
    const now = Date.now();
    const record = loginAttempts.get(key);

    if (record && now - record.startedAt < LOGIN_WINDOW_MS &&
        record.failures >= MAX_LOGIN_FAILURES) {
      return res.status(429).json({
        error: "Too many login attempts. Try again later."
      });
    }

    if (record && now - record.startedAt >= LOGIN_WINDOW_MS) {
      loginAttempts.delete(key);
    }

    next();
  }

  router.post("/login", loginRateLimit, (req, res) => {
    const { username, password } = req.body || {};

    if (typeof username !== "string" ||
        typeof password !== "string" ||
        !username.trim() || !password) {
      return res.status(400).json({ error: "Username and password required" });
    }

    db.get(
      "SELECT id, username, password_hash, role FROM admin_users WHERE username = ? AND status = 'ACTIVE'",
      [username.trim()],
      (err, user) => {
        if (err) return res.status(500).json({ error: "Database error" });

        if (!user || !verifyPassword(password, user.password_hash)) {
          const key = req.ip;
          const now = Date.now();
          let record = loginAttempts.get(key);

          if (!record || now - record.startedAt >= LOGIN_WINDOW_MS) {
            record = { startedAt: now, failures: 0 };
          }

          record.failures += 1;
          loginAttempts.set(key, record);

          return res.status(401).json({ error: "Invalid credentials" });
        }

        loginAttempts.delete(req.ip);

        const token = createToken();
        const expiresAt = Date.now() + SESSION_LIFETIME_MS;

        db.run(
          "INSERT INTO admin_sessions (admin_user_id, token_hash, expires_at) VALUES (?, ?, ?)",
          [user.id, hashToken(token), expiresAt],
          (err) => {
            if (err) return res.status(500).json({ error: "Session error" });

            res.json({
              token,
              expiresAt,
              user: {
                id: user.id,
                username: user.username,
                role: user.role
              }
            });
          }
        );
      }
    );
  });


  function requireAdmin(req, res, next) {
    const authorization = req.get("Authorization") || "";
    const match = /^Bearer ([a-f0-9]{64})$/.exec(authorization);

    if (!match) {
      return res.status(401).json({ error: "Authentication required" });
    }

    const tokenHash = hashToken(match[1]);

    db.get(
      `SELECT u.id, u.username, u.role
       FROM admin_sessions s
       JOIN admin_users u ON u.id = s.admin_user_id
       WHERE s.token_hash = ?
         AND s.expires_at > ?
         AND u.status = 'ACTIVE'`,
      [tokenHash, Date.now()],
      (err, user) => {
        if (err) return res.status(500).json({ error: "Database error" });

        if (!user) {
          return res.status(401).json({ error: "Invalid or expired session" });
        }

        req.admin = user;
        next();
      }
    );
  }

  router.get("/me", requireAdmin, (req, res) => {
    res.json({ user: req.admin });
  });


  router.post("/logout", requireAdmin, (req, res) => {
    const token = req.get("Authorization").slice(7);

    db.run(
      "DELETE FROM admin_sessions WHERE token_hash = ?",
      [hashToken(token)],
      function(err) {
        if (err) {
          return res.status(500).json({ error: "Logout failed" });
        }

        res.json({ success: true });
      }
    );
  });


  router.get("/shops", requireAdmin, (req, res) => {
    db.all(
      `SELECT shop_id, shop_name, payment_mode, status, created_at
       FROM shops
       ORDER BY shop_id`,
      [],
      (err, rows) => {
        if (err) {
          return res.status(500).json({ error: "Database error" });
        }

        res.json({ shops: rows });
      }
    );
  });


  router.post("/shops", requireAdmin, (req, res) => {
    const { shop_id, shop_name } = req.body || {};

    if (
      typeof shop_id !== "string" ||
      !/^shop[a-zA-Z0-9_-]{1,30}$/.test(shop_id) ||
      typeof shop_name !== "string" ||
      !shop_name.trim() ||
      shop_name.trim().length > 100
    ) {
      return res.status(400).json({
        error: "Invalid shop ID or shop name"
      });
    }

    db.run(
      `INSERT INTO shops (shop_id, shop_name, payment_mode, status)
       VALUES (?, ?, 'CENTRAL', 'ACTIVE')`,
      [shop_id, shop_name.trim()],
      function (err) {
        if (err) {
          if (err.code === "SQLITE_CONSTRAINT") {
            return res.status(409).json({
              error: "Shop ID already exists"
            });
          }

          return res.status(500).json({
            error: "Database error"
          });
        }

        res.status(201).json({
          shop: {
            shop_id,
            shop_name: shop_name.trim(),
            payment_mode: "CENTRAL",
            status: "ACTIVE"
          }
        });
      }
    );
  });

  router.get("/shops/:shopId/machines", requireAdmin, (req, res) => {
    db.all(
      `SELECT machine, shop_id, machine_type, model,
              display_name, program_profile, state, status, enabled, deleted_at,
              CASE WHEN state='RUNNING' THEN
                (SELECT started_at FROM machine_run_clock c WHERE c.machine=machines.machine)
              END AS run_started_at,
              CASE WHEN state='RUNNING' THEN
                (SELECT estimated_minutes FROM machine_run_clock c WHERE c.machine=machines.machine)
              END AS estimated_minutes
       FROM machines
       WHERE shop_id = ?
       ORDER BY machine`,
      [req.params.shopId],
      (err, rows) => {
        if (err) {
          return res.status(500).json({ error: "Database error" });
        }

        res.json({ machines: rows });
      }
    );
  });


  router.post("/shops/:shopId/machines", requireAdmin, async (req, res) => {
    const shopId = req.params.shopId;
    const { machine_type, model, display_name, program_profile } = req.body || {};

    if (
      typeof machine_type !== "string" ||
      !["wash", "dry"].includes(machine_type) ||
      typeof display_name !== "string" ||
      !display_name.trim() ||
      display_name.trim().length > 100 ||
      (model != null && (typeof model !== "string" || model.length > 100)) ||
      (program_profile != null &&
        (typeof program_profile !== "string" ||
         program_profile.length > 100))
    ) {
      return res.status(400).json({ error: "Invalid machine data" });
    }

    const writeDb = new sqlite3.Database(dbPath);

    const run = (sql, params = []) => new Promise((resolve, reject) => {
      writeDb.run(sql, params, function (err) {
        if (err) reject(err);
        else resolve(this);
      });
    });

    const get = (sql, params = []) => new Promise((resolve, reject) => {
      writeDb.get(sql, params, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    const close = () => new Promise((resolve) => writeDb.close(() => resolve()));

    let transactionStarted = false;

    try {
      await run("PRAGMA busy_timeout = 10000");
      await run("BEGIN IMMEDIATE");
      transactionStarted = true;

      const shop = await get(
        "SELECT shop_id FROM shops WHERE shop_id = ? AND status = 'ACTIVE'",
        [shopId]
      );

      if (!shop) {
        await run("ROLLBACK");
        transactionStarted = false;
        return res.status(404).json({ error: "Shop not found" });
      }

      const counter = await get(
        "SELECT last_number FROM machine_id_counter WHERE id = 1"
      );

      if (!counter || !Number.isSafeInteger(counter.last_number)) {
        throw new Error("Machine ID counter missing or invalid");
      }

      const nextNumber = counter.last_number + 1;

      if (!Number.isSafeInteger(nextNumber)) {
        throw new Error("Machine ID counter exhausted");
      }

      const machine = `machine${nextNumber}`;

      await run(
        "UPDATE machine_id_counter SET last_number = ? WHERE id = 1",
        [nextNumber]
      );

      await run(
        `INSERT INTO machines
         (machine, shop_id, machine_type, model, display_name,
          program_profile, state, status)
         VALUES (?, ?, ?, ?, ?, ?, 'IDLE', 'OFFLINE')`,
        [
          machine,
          shopId,
          machine_type,
          model?.trim() || null,
          display_name.trim(),
          program_profile?.trim() || null
        ]
      );

      await run("COMMIT");
      transactionStarted = false;
      onMachinesChanged();

      return res.status(201).json({
        machine: {
          machine,
          shop_id: shopId,
          machine_type,
          model: model?.trim() || null,
          display_name: display_name.trim(),
          program_profile: program_profile?.trim() || null,
          state: "IDLE",
          status: "OFFLINE"
        }
      });
    } catch (err) {
      if (transactionStarted) {
        try {
          await run("ROLLBACK");
        } catch (rollbackErr) {
          console.error("Machine allocation rollback failed:", rollbackErr);
        }
      }

      console.error("Machine allocation failed:", err);
      return res.status(500).json({ error: "Machine registration failed" });
    } finally {
      await close();
    }
  });



  // Edit machine metadata without changing machine identity or history
  router.patch("/shops/:shopId/machines/:machine", requireAdmin, async (req, res) => {
    const { shopId, machine } = req.params;
    const { display_name, model, program_profile } = req.body || {};

    if (
      typeof display_name !== "string" ||
      !display_name.trim() ||
      display_name.trim().length > 100 ||
      (model != null && (typeof model !== "string" || model.length > 100)) ||
      (program_profile != null &&
        (typeof program_profile !== "string" || program_profile.length > 100))
    ) {
      return res.status(400).json({ error: "Invalid machine data" });
    }

    const writeDb = new sqlite3.Database(dbPath);
    const run = (sql, params = []) => new Promise((resolve, reject) =>
      writeDb.run(sql, params, function(err) {
        err ? reject(err) : resolve(this);
      })
    );
    const get = (sql, params = []) => new Promise((resolve, reject) =>
      writeDb.get(sql, params, (err, row) =>
        err ? reject(err) : resolve(row)
      )
    );
    const close = () => new Promise(resolve => writeDb.close(() => resolve()));

    let inTransaction = false;

    try {
      await run("PRAGMA busy_timeout = 10000");
      await run("BEGIN IMMEDIATE");
      inTransaction = true;

      const row = await get(
        `SELECT machine, state, reserved_until, deleted_at
         FROM machines WHERE machine = ? AND shop_id = ?`,
        [machine, shopId]
      );

      if (!row) {
        await run("ROLLBACK");
        inTransaction = false;
        return res.status(404).json({ error: "Machine not found" });
      }

      if (row.deleted_at != null) {
        await run("ROLLBACK");
        inTransaction = false;
        return res.status(409).json({ error: "Machine has been deleted" });
      }

      if (row.state !== "IDLE" || (row.reserved_until && row.reserved_until > Date.now())) {
        await run("ROLLBACK");
        inTransaction = false;
        return res.status(409).json({ error: "Machine is busy" });
      }

      await run(
        `UPDATE machines
         SET display_name = ?, model = ?, program_profile = ?
         WHERE machine = ? AND shop_id = ?`,
        [
          display_name.trim(),
          model?.trim() || null,
          program_profile?.trim() || null,
          machine,
          shopId
        ]
      );

      await run("COMMIT");
      inTransaction = false;

      return res.json({
        machine,
        shop_id: shopId,
        display_name: display_name.trim(),
        model: model?.trim() || null,
        program_profile: program_profile?.trim() || null
      });
    } catch (err) {
      if (inTransaction) {
        try { await run("ROLLBACK"); } catch (_) {}
      }
      console.error("Machine metadata update failed:", err);
      return res.status(500).json({ error: "Machine update failed" });
    } finally {
      await close();
    }
  });


  router.patch("/shops/:shopId/machines/:machine/delete", requireAdmin, async (req, res) => {
    const { shopId, machine } = req.params;
    const writeDb = new sqlite3.Database(dbPath);
    const run = (sql, params = []) => new Promise((resolve, reject) =>
      writeDb.run(sql, params, function(err) { err ? reject(err) : resolve(this); })
    );
    const get = (sql, params = []) => new Promise((resolve, reject) =>
      writeDb.get(sql, params, (err, row) => err ? reject(err) : resolve(row))
    );
    const close = () => new Promise(resolve => writeDb.close(() => resolve()));

    let inTransaction = false;
    try {
      await run("PRAGMA busy_timeout = 10000");
      await run("BEGIN IMMEDIATE");
      inTransaction = true;

      const row = await get(
        `SELECT state, reserved_until, deleted_at
         FROM machines WHERE machine = ? AND shop_id = ?`,
        [machine, shopId]
      );

      if (!row) {
        await run("ROLLBACK");
        inTransaction = false;
        return res.status(404).json({ error: "Machine not found" });
      }

      if (row.deleted_at != null) {
        await run("ROLLBACK");
        inTransaction = false;
        return res.status(409).json({ error: "Machine already deleted" });
      }

      if (row.state !== "IDLE" ||
          (row.reserved_until != null && row.reserved_until > Date.now())) {
        await run("ROLLBACK");
        inTransaction = false;
        return res.status(409).json({ error: "Machine is busy" });
      }

      const deletedAt = Date.now();
      await run(
        `UPDATE machines
         SET enabled = 0, deleted_at = ?
         WHERE machine = ? AND shop_id = ? AND deleted_at IS NULL`,
        [deletedAt, machine, shopId]
      );

      await run("COMMIT");
      inTransaction = false;
      onMachinesChanged();
      return res.json({ machine, shop_id: shopId, enabled: 0, deleted_at: deletedAt });
    } catch (err) {
      if (inTransaction) {
        try { await run("ROLLBACK"); } catch (_) {}
      }
      console.error("Machine soft delete failed:", err);
      return res.status(500).json({ error: "Machine delete failed" });
    } finally {
      await close();
    }
  });

  router.patch("/shops/:shopId/machines/:machine/enabled", requireAdmin, async (req, res) => {
    const { shopId, machine } = req.params;
    const { enabled } = req.body || {};

    if (typeof enabled !== "boolean") {
      return res.status(400).json({ error: "enabled must be boolean" });
    }

    const writeDb = new sqlite3.Database(dbPath);
    const run = (sql, params = []) => new Promise((resolve, reject) => {
      writeDb.run(sql, params, function (err) {
        if (err) reject(err);
        else resolve(this);
      });
    });
    const get = (sql, params = []) => new Promise((resolve, reject) => {
      writeDb.get(sql, params, (err, row) => err ? reject(err) : resolve(row));
    });
    const close = () => new Promise(resolve => writeDb.close(() => resolve()));

    let inTransaction = false;

    try {
      await run("PRAGMA busy_timeout = 10000");
      await run("BEGIN IMMEDIATE");
      inTransaction = true;

      const row = await get(
        "SELECT machine, state, reserved_until, enabled, deleted_at FROM machines WHERE machine = ? AND shop_id = ?",
        [machine, shopId]
      );

      if (!row) {
        await run("ROLLBACK");
        inTransaction = false;
        return res.status(404).json({ error: "Machine not found" });
      }

      if (row.deleted_at != null) {
        await run("ROLLBACK");
        inTransaction = false;
        return res.status(409).json({ error: "Machine has been deleted" });
      }

      if (!enabled && (
        row.state !== "IDLE" ||
        (row.reserved_until != null && row.reserved_until > Date.now())
      )) {
        await run("ROLLBACK");
        inTransaction = false;
        return res.status(409).json({ error: "Machine is not idle" });
      }

      await run(
        "UPDATE machines SET enabled = ? WHERE machine = ? AND shop_id = ?",
        [enabled ? 1 : 0, machine, shopId]
      );

      await run("COMMIT");
      inTransaction = false;

      return res.json({ machine, shop_id: shopId, enabled: enabled ? 1 : 0 });
    } catch (err) {
      if (inTransaction) {
        try { await run("ROLLBACK"); } catch (_) {}
      }
      console.error("Admin machine enabled update failed:", err);
      return res.status(500).json({ error: "Machine update failed" });
    } finally {
      await close();
    }
  });



  // Admin CLEAR: request ESP32 RESET via shop-scoped MQTT, then clear server state.
  router.patch("/shops/:shopId/machines/:machine/clear", requireAdmin, async (req, res) => {
    const { shopId, machine } = req.params;
    if (!/^shop[a-zA-Z0-9_-]{1,30}$/.test(shopId) || !/^machine\d+$/.test(machine)) {
      return res.status(400).json({ error: "Invalid shop or machine" });
    }
    if (typeof sendMqttCommand !== "function") {
      return res.status(503).json({ error: "MQTT command service unavailable" });
    }

    const writeDb = new sqlite3.Database(dbPath);
    const run = (sql, params = []) => new Promise((resolve, reject) =>
      writeDb.run(sql, params, function (err) { err ? reject(err) : resolve(this); }));
    const get = (sql, params = []) => new Promise((resolve, reject) =>
      writeDb.get(sql, params, (err, row) => err ? reject(err) : resolve(row)));
    const close = () => new Promise(resolve => writeDb.close(() => resolve()));
    let started = false;

    try {
      await run("PRAGMA busy_timeout = 10000");
      await run("BEGIN IMMEDIATE");
      started = true;
      const row = await get(
        `SELECT state, status, reserved_until, deleted_at
         FROM machines WHERE machine = ? AND shop_id = ?`,
        [machine, shopId]
      );
      if (!row || row.deleted_at != null) {
        await run("ROLLBACK"); started = false;
        return res.status(404).json({ error: "Machine not found" });
      }
      if (row.state === "RESERVED" && Number(row.reserved_until) > Date.now()) {
        await run("ROLLBACK"); started = false;
        return res.status(409).json({ error: "Machine has an active reservation" });
      }
      // MQTT QoS 1 acknowledges broker delivery, not ESP32 execution.
      // Do not mark the server IDLE if publishing fails.
      await sendMqttCommand(shopId, machine, { action: "reset" });
      await run(
        `UPDATE machines
         SET state = 'IDLE', reserved_until = NULL, reservation_txid = NULL
         WHERE machine = ? AND shop_id = ?`,
        [machine, shopId]
      );
      await run("DELETE FROM machine_run_clock WHERE machine = ?", [machine]);
      await run("COMMIT");
      started = false;
      return res.json({ success: true, machine, shop_id: shopId, state: "IDLE" });
    } catch (err) {
      if (started) { try { await run("ROLLBACK"); } catch (_) {} }
      console.error("Admin CLEAR failed:", err);
      return res.status(500).json({ error: "CLEAR failed" });
    } finally {
      await close();
    }
  });

  // Admin-only simulation of the ESP32 finish command.
  router.post("/shops/:shopId/machines/:machine/finish", requireAdmin, (req, res) => {
    const { shopId, machine } = req.params;
    if (!/^shop[a-zA-Z0-9_-]{1,30}$/.test(shopId) || !/^machine\d+$/.test(machine)) {
      return res.status(400).json({ error: "Invalid shop or machine" });
    }
    if (typeof sendMqttCommand !== "function") {
      return res.status(503).json({ error: "MQTT command service unavailable" });
    }
    db.get(
      `SELECT machine FROM machines
       WHERE shop_id = ? AND machine = ? AND deleted_at IS NULL`,
      [shopId, machine],
      async (err, row) => {
        if (err) return res.status(500).json({ error: "Database error" });
        if (!row) return res.status(404).json({ error: "Machine not found in shop" });
        try {
          await sendMqttCommand(shopId, machine, { action: "finish" });
          return res.json({ success: true, shop_id: shopId, machine });
        } catch (error) {
          console.error("Admin FINISH failed:", error);
          return res.status(500).json({ error: "FINISH command failed" });
        }
      }
    );
  });

  // Shop-specific pricing: read the effective catalog for a machine.
  router.get("/shops/:shopId/machines/:machine/pricing", requireAdmin, async (req, res) => {
    const { shopId, machine } = req.params;
    if (!/^machine\d+$/.test(machine)) {
      return res.status(400).json({ error: "Invalid machine" });
    }
    db.get(
      `SELECT machine FROM machines WHERE machine = ? AND shop_id = ? AND deleted_at IS NULL`,
      [machine, shopId],
      async (err, row) => {
        if (err) return res.status(500).json({ error: "Database error" });
        if (!row) return res.status(404).json({ error: "Machine not found in shop" });
        try {
          const { getPricingCatalog } = require("./payment-pricing-catalog.cjs");
          const catalog = await getPricingCatalog(machine, { dbPath });
          res.set("Cache-Control", "no-store");
          return res.json({ success: true, shop_id: shopId, ...catalog });
        } catch (error) {
          console.error("Admin pricing read failed:", error);
          return res.status(500).json({ error: "Pricing read failed" });
        }
      }
    );
  });


  // Save machine-specific pricing without changing the firmware program IDs.
  router.patch("/shops/:shopId/machines/:machine/pricing", requireAdmin, async (req, res) => {
    const { shopId, machine } = req.params;
    const pricing = req.body?.pricing;
    if (!/^machine\d+$/.test(machine) || !pricing || typeof pricing !== "object" || Array.isArray(pricing)) {
      return res.status(400).json({ error: "Invalid machine or pricing" });
    }

    const validMoney = (v, positive = false) =>
      typeof v === "number" && Number.isFinite(v) &&
      (positive ? v > 0 : v >= 0) && v <= 100000 &&
      Number.isSafeInteger(Math.round(v * 100)) &&
      Math.abs(v * 100 - Math.round(v * 100)) < 1e-7;
    const validPrices = (obj) => obj && typeof obj === "object" &&
      !Array.isArray(obj) && Object.values(obj).every(v => validMoney(v));
    const groups = pricing.priceGroups;
    if (!groups || typeof groups !== "object" || Array.isArray(groups) ||
        !Object.keys(groups).length || Object.entries(groups).some(([price, programs]) =>
          !/^\d+(?:\.\d{1,2})?$/.test(price) || !validMoney(Number(price), true) ||
          !Array.isArray(programs) || !programs.length ||
          programs.some(id => !Number.isSafeInteger(id) || id <= 0))) {
      return res.status(400).json({ error: "Invalid price groups" });
    }
    const programIds = Object.values(groups).flat();
    if (new Set(programIds).size !== programIds.length) {
      return res.status(400).json({ error: "Program appears in more than one price group" });
    }

    const writeDb = new sqlite3.Database(dbPath);
    const get = (sql, params = []) => new Promise((resolve, reject) =>
      writeDb.get(sql, params, (err, row) => err ? reject(err) : resolve(row)));
    const run = (sql, params = []) => new Promise((resolve, reject) =>
      writeDb.run(sql, params, function (err) { err ? reject(err) : resolve(this); }));
    let started = false;
    try {
      await run("PRAGMA busy_timeout = 10000");
      await run("BEGIN IMMEDIATE");
      started = true;
      const row = await get(
        `SELECT machine_type, program_profile FROM machines
         WHERE machine = ? AND shop_id = ? AND deleted_at IS NULL`,
        [machine, shopId]
      );
      if (!row) {
        await run("ROLLBACK"); started = false;
        return res.status(404).json({ error: "Machine not found in shop" });
      }
      if (!row.program_profile) {
        await run("ROLLBACK"); started = false;
        return res.status(409).json({ error: "Machine has no program profile" });
      }
      const type = row.machine_type;
      const allowed = type === "wash"
        ? ["priceGroups", "temperaturePrice", "aromaPrice"]
        : ["priceGroups", "temperatureRule", "wrinklePrice"];
      if (!allowed.every(k => Object.hasOwn(pricing, k)) ||
          Object.keys(pricing).some(k => !allowed.includes(k)) ||
          (type === "wash" && (!validPrices(pricing.temperaturePrice) || !validMoney(pricing.aromaPrice))) ||
          (type === "dry" && (!pricing.temperatureRule ||
            !Array.isArray(pricing.temperatureRule.programs) ||
            new Set(pricing.temperatureRule.programs).size !== pricing.temperatureRule.programs.length ||
            pricing.temperatureRule.programs.some(id => !programIds.includes(id)) ||
            !validPrices(pricing.temperatureRule.prices) ||
            !validMoney(pricing.wrinklePrice))) ||
          !["wash", "dry"].includes(type)) {
        await run("ROLLBACK"); started = false;
        return res.status(400).json({ error: "Invalid pricing structure for machine type" });
      }
      await run(
        `INSERT INTO shop_machine_pricing
           (shop_id, machine, program_profile, pricing_json, updated_at)
         VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
         ON CONFLICT(machine) WHERE machine IS NOT NULL DO UPDATE SET
           shop_id = excluded.shop_id,
           program_profile = excluded.program_profile,
           pricing_json = excluded.pricing_json,
           updated_at = CURRENT_TIMESTAMP`,
        [shopId, machine, row.program_profile, JSON.stringify(pricing)]
      );
      await run("COMMIT"); started = false;
      res.set("Cache-Control", "no-store");
      return res.json({ success: true, shop_id: shopId, machine, pricingSource: "machine", pricing });
    } catch (error) {
      if (started) { try { await run("ROLLBACK"); } catch (_) {} }
      console.error("Admin pricing save failed:", error);
      return res.status(500).json({ error: "Pricing save failed" });
    } finally {
      await new Promise(resolve => writeDb.close(() => resolve()));
    }
  });


  // Read-only dashboard: paid orders and per-cycle usage; never controls machines.
  router.get("/dashboard", requireAdmin, async (req, res) => {
    const shopId = req.query.shop_id || "all";
    const from = req.query.from;
    const to = req.query.to;
    const dateRe = /^\d{4}-\d{2}-\d{2}$/;
    if (typeof shopId !== "string" || shopId.length > 64 ||
        typeof from !== "string" || typeof to !== "string" ||
        !dateRe.test(from) || !dateRe.test(to)) {
      return res.status(400).json({ error: "shop_id, from and to (YYYY-MM-DD) required" });
    }
    // Reporting day is Thailand local time. Date range is inclusive.
    const start = Date.parse(`${from}T00:00:00+07:00`);
    const end = Date.parse(`${to}T00:00:00+07:00`) + 86400000;
    if (!Number.isFinite(start) || !Number.isFinite(end) ||
        new Date(start + 25200000).toISOString().slice(0, 10) !== from ||
        new Date(end - 86400000 + 25200000).toISOString().slice(0, 10) !== to ||
        end <= start || end - start > 366 * 86400000) {
      return res.status(400).json({ error: "Invalid date range (maximum 366 days)" });
    }
    const all = (sql, params = []) => new Promise((resolve, reject) =>
      db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows)));
    const localDay = (ms) => new Date(ms + 25200000).toISOString().slice(0, 10);
    const finite = (v) => v !== null && v !== undefined && Number.isFinite(Number(v));
    try {
      const shops = await all("SELECT shop_id, shop_name FROM shops ORDER BY shop_id");
      if (shopId !== "all" && !shops.some(s => s.shop_id === shopId)) {
        return res.status(404).json({ error: "Shop not found" });
      }
      const machines = await all(
        `SELECT machine, shop_id, display_name, machine_type FROM machines
         WHERE (? = 'all' OR shop_id = ?) ORDER BY shop_id, machine`,
        [shopId, shopId]);
      const machineMap = new Map(machines.map(m => [m.machine, m]));
      const orders = await all(
        `SELECT txid, machine, shop_id, amount_satang, created_at
         FROM payment_orders WHERE status = 'PAID' AND is_test = 0
         AND created_at >= ? AND created_at < ?
         AND (? = 'all' OR shop_id = ?)
         ORDER BY created_at DESC`, [start, end, shopId, shopId]);
      const usage = await all(
        `SELECT u.txid, u.machine, u.started_at, u.finished_at, u.status,
                u.energy_used_kwh, u.water_used_liters,
                u.energy_calculated_kwh
         FROM machine_usage u
         WHERE u.started_at IS NOT NULL
         ORDER BY u.started_at DESC`);
      const summary = { paid_orders: 0, revenue_satang: 0, usage_cycles: 0,
        completed_cycles: 0, energy_kwh: 0, water_liters: 0,
        energy_samples: 0, water_samples: 0, estimated_cycles: 0 };
      const byMachine = new Map(machines.map(m => [m.machine, {
        ...m, paid_orders: 0, revenue_satang: 0, usage_cycles: 0,
        completed_cycles: 0, energy_kwh: 0, water_liters: 0,
        energy_samples: 0, water_samples: 0, estimated_cycles: 0
      }]));
      const byDay = new Map();
      function dayRecord(day) {
        if (!byDay.has(day)) byDay.set(day, { day, paid_orders: 0,
          revenue_satang: 0, usage_cycles: 0, energy_kwh: 0, water_liters: 0 });
        return byDay.get(day);
      }
      for (const o of orders) {
        if (!Number.isSafeInteger(o.amount_satang) || o.amount_satang < 0) continue;
        // Order shop_id is authoritative even if machine metadata later changes.
        summary.paid_orders++; summary.revenue_satang += o.amount_satang;
        const day = dayRecord(localDay(o.created_at));
        day.paid_orders++; day.revenue_satang += o.amount_satang;
        const m = byMachine.get(o.machine);
        if (m && m.shop_id === o.shop_id) {
          m.paid_orders++; m.revenue_satang += o.amount_satang;
        }
      }
      const recentUsage = [];
      for (const u of usage) {
        const m = machineMap.get(u.machine);
        if (!m) continue;
        const timestamp = Date.parse(u.started_at);
        if (!Number.isFinite(timestamp) || timestamp < start || timestamp >= end) continue;
        const day = dayRecord(localDay(timestamp));
        summary.usage_cycles++; byMachine.get(u.machine).usage_cycles++;
        day.usage_cycles++;
        const completed = ["FINISHED", "FINISHED_ESTIMATED"].includes(u.status);
        if (completed) {
          summary.completed_cycles++; byMachine.get(u.machine).completed_cycles++;
          if (u.status === "FINISHED_ESTIMATED") {
            summary.estimated_cycles++; byMachine.get(u.machine).estimated_cycles++;
          }
          if (finite(u.energy_used_kwh) && Number(u.energy_used_kwh) >= 0) {
            const value = Number(u.energy_used_kwh);
            summary.energy_kwh += value; byMachine.get(u.machine).energy_kwh += value;
            summary.energy_samples++; byMachine.get(u.machine).energy_samples++;
            day.energy_kwh += value;
          }
          if (finite(u.water_used_liters) && Number(u.water_used_liters) >= 0) {
            const value = Number(u.water_used_liters);
            summary.water_liters += value; byMachine.get(u.machine).water_liters += value;
            summary.water_samples++; byMachine.get(u.machine).water_samples++;
            day.water_liters += value;
          }
        }
        if (recentUsage.length < 100) recentUsage.push({
          txid: u.txid, machine: u.machine, shop_id: m.shop_id,
          started_at: u.started_at, finished_at: u.finished_at,
          status: u.status, energy_used_kwh: u.energy_used_kwh,
          water_used_liters: u.water_used_liters
        });
      }
      res.set("Cache-Control", "no-store");
      return res.json({ success: true, shop_id: shopId, from, to,
        timezone: "Asia/Bangkok", revenue_source: "payment_orders.PAID (is_test=0)",
        legacy_transactions_included: false,
        usage_shop_attribution: "current machine.shop_id",
        shops, summary, machines: [...byMachine.values()],
        daily: [...byDay.values()].sort((a, b) => a.day.localeCompare(b.day)),
        recent_usage: recentUsage });
    } catch (error) {
      console.error("Admin dashboard failed:", error);
      return res.status(500).json({ error: "Dashboard query failed" });
    }
  });

  return router;
}

module.exports = { createAdminRouter };
